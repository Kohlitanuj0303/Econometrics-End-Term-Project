# Econometrics-End-Term-Project
Solve two questions using hypothesis testing and given data
